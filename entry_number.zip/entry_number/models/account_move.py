from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    entry_number = fields.Char(
        string='Entry Number',
        readonly=True,
        copy=False,      # الدوبليكيت والعكس ياخدوا رقم جديد
        index=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        seq = self.env['ir.sequence']
        for vals in vals_list:
            if not vals.get('entry_number'):
                vals['entry_number'] = seq.next_by_code('account.move.entry.number')
        return super().create(vals_list)
